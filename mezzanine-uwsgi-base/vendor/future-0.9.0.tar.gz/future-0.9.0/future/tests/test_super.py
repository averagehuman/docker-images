'''
Tests for the new super() function syntax
'''
from __future__ import absolute_import, print_function
from future.builtins.backports import super
from future.tests.base import unittest


if __name__ == '__main__':
    unittest.main()
