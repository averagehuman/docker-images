NAME='router_radius'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['radius']
