NAME='transformation_gzip'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['gzip']
