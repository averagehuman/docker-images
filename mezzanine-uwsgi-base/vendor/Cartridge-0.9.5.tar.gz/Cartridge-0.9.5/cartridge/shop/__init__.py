from __future__ import unicode_literals

from cartridge import __version__
