========
Colophon
========

Authors
=======

.. include:: ../AUTHORS

License
=======

.. include:: ../LICENSE

Change Log
==========

.. include:: ../CHANGELOG
