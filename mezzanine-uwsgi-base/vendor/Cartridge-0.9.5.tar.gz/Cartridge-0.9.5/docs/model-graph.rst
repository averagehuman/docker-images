===========
Model Graph
===========

The diagram below depicts the fields and relationships for all the
models in Mezzanine and Cartridge. Click it to view a full version.

.. image:: img/graph-small.png
   :align: center
   :width: 800 px
   :target: _images/graph.png
