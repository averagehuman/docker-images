from __future__ import unicode_literals
VERSION = '2.0'